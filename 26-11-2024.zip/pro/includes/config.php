<?php 

define('HOST', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASE', 'pro');

define('BASEURL', 'http://localhost/pro/');
// echo $_SERVER['REQUEST_URI'];
// echo "<br />". $folder = str_replace('/', '', $_SERVER['REQUEST_URI']);
// define('DIR', $folder);

define('CURRENCY', '&#8377');


define('DOCROOT', dirname(__DIR__));

/* load all classes here */
require_once('database.php');
require_once('classes/auth.php');
require_once('classes/lib.php');
require_once('classes/staff.php');
/* load all classes here */

spl_autoload_register(function($class){
    $filename = DOCROOT . "/classes/" . strtolower($class) . ".php";
    if(file_exists($filename)){
        include_once $filename;
    }
});

/* login user data*/
$obj = new auth();
$lib = new lib();
$getuserdata = $lib->userdata();

$csrf_token = $lib->generateCsrfToken();






?>