<?php 
class db{

    protected $mysqli;

    public function __construct(){
        $this->mysqli = new mysqli(HOST, USERNAME, PASSWORD, DATABASE);
        if($this->mysqli->connect_error){
            die('Connection Error ('. $this->mysqli->connect_errno. ')' . $this->mysqli->connect_error);
        }
    }

    public function __destruct(){
        $this->mysqli->close();
    }

    function int($data){
    $data = filter_var($data, FILTER_SANITIZE_NUMBER_INT);
    return $data;
    }

    function sanitize($data){
        $data = filter_var($data, FILTER_SANITIZE_FULL_SPECIAL_CHARS, FILTER_FLAG_STRIP_HIGH);
        $data = trim($data);
        $data = stripslashes($data);
        $data = $this->mysqli->real_escape_string($data);
        return $data;
    }


   


    function insert_query($table, $data, $csrf){
        $data = array_filter($data);
        // echo "<pre>";
        // print_r($data);

        //insert into staff (name, contact, post, city) values ('name');

        $values = "";
         $key = array_keys($data);
         $key = implode(", ", $key);

         foreach($data as $value){
            $values .= $this->sanitize($value). "', '";
         }
         
         $values = trim ($values, ", '");
        //  echo $values;
        @session_start();
        if($csrf == $_SESSION['csrf_token']){
           $query = "INSERT INTO $table ($key) 
          values
          ('$values')";

          return $this->mysqli->query($query);
    }else{
        return false;
    }

    }



    

}

?>