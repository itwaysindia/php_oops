<?php
class auth extends db{

    public function getConnection(){
        return $this->mysqli;
    }


    function login(){
        echo $_POST['email'];
        echo $pass = md5($_POST['password']);

        $data = $this->mysqli->query("SELECT * FROM users where email= '$_POST[email]' AND password = '$pass' AND status = '1'");

        if($data->num_rows){
            $data_obj = $data->fetch_object();

            session_start();
      $_SESSION['admin'] = $data_obj->id;
       $_SESSION['email'] = $data_obj->email;


       if(isset($_POST['remember_me'])){
        $token = hash('sha256', $data_obj->id . $data_obj->email);
        setcookie('remember_me', $token, time() + 86400, '/', '', true, true );
        setcookie('user_id', $data_obj->id, time() + 86400, '/', '', true, true );
       }


            header("location: ../index.php");
            die;
        }else{
            @session_start();
            $_SESSION['fal'] = 'Incorrect Credentials or Your A/c is blocked';
            header("location: ?login-error");
            die;
        }
    }

    function register(){
        echo "Register Method";
       
       
        // $query->autoinsert('users');
    }



function check_session(){
@session_start();
// check if remember_me cookie is valid 
if(isset($_COOKIE['remember_me']) && isset($_COOKIE['user_id'])){
    $user_id = $_COOKIE['user_id'];
    $token = $_COOKIE['remember_me'];

    $data = $this->mysqli->query("SELECT * FROM users where id= '$user_id' AND status = '1'");
    if($data->num_rows){
        $data_obj = $data->fetch_object();
        $valid_token = hash('sha256', $data_obj->id . $data_obj->email);

        if($token == $valid_token){
            $_SESSION['admin'] = $data_obj->id;
            $_SESSION['email'] = $data_obj->email;
        }
    }
}
if(isset($_SESSION['admin']) == ''){

    // echo "<h1>Session Check</h1>";
session_destroy();
header("location: auth/index.php");
die;
}
}


function message(){

    if(@$_SESSION['suc']){
        echo '<div class="alert alert-success" id="alert-success">
        <button type="button" class="close" data-dissmiss="alert" aria-hidden="true">x</button>
        <strong>Success: </strong> '. $_SESSION['suc'] .'
        </div>';
        unset($_SESSION['suc']);
    }elseif(@$_SESSION['fal']){
        echo '<div class="alert alert-danger" id="alert-success">
        <button type="button" class="close" data-dissmiss="alert" aria-hidden="true">x</button>
        <strong>Success: </strong> '. $_SESSION['fal'] .'
        </div>';
        unset($_SESSION['fal']);
    }
   
    
}

function logout(){
    session_start();
    session_destroy();

    //clear cookies
    setcookie('remember_me', '', time() -3600, '/');
    setcookie('user_id', '', time() -3600, '/');

    header("location: auth/index.php");
    die;
}

}

 
if(isset($_POST['login'])){
    $obj = new auth();
    $obj->login();
}
if(isset($_POST['signup'])){
    $obj = new auth();
    $obj->register();
}

if(isset($_GET['act']) == 'logout'){
    $obj = new auth();
    $obj->logout();
}
?>