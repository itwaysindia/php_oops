<?php 

class staff extends db{
    function new_staff()
    {
        $data = array(
            'name' => $_POST['name'],
            'contact' => $_POST['contact'],
            'post' => $_POST['post'],
            'city' => $_POST['city']
        );
       $csrf = $_POST['csrf_token'];
        // print_r($data);
        $data = $this->insert_query('staff', $data, $csrf);
        if($data){
            @session_start();
            $_SESSION['suc'] = 'Record Updated Successfully';
        }else{
            $_SESSION['fal'] = 'Something Went Wrong!';
        }
        header("location: ?nav=form");
        die;
    }
}

if(isset($_POST['new-staff'])){
    $staff = new staff();
    $staff->new_staff();
}

?>