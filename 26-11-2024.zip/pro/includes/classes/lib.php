<?php 
class lib extends db{

    function userdata(){
        @session_start();
        $user_id = $_SESSION['admin'];
        if($user_id){
            $data = $this->mysqli->query("select * from users where id = $user_id");
            if($data->num_rows){
                return $data->fetch_object();
            }else{
                $obj = new auth();
                $obj->logout();
            }
        }
    }

    
    function generateCsrfToken(){
        @SESSION_START();
        if(empty($_SESSION['csrf_token'])){
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }


}
?>