<?php include('layout/header.php'); ?>
<div class="app-wrapper"> <!--begin::Header-->
        <?php 
        include('layout/sidebar.php');
        ?>
       
<div class="row">
    <?= $obj->message(); ?>
    <div class="col-sm-12 mt-5">
        <form action="" method="POST">
            <input type="text" class="form-control" name="name" placeholder="Staff Name">
            <input type="text" class="form-control" name="contact" placeholder="Contact">
            <input type="text" class="form-control" name="post" placeholder="Designation">
            <input type="text" class="form-control" name="city" placeholder="City">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token; ?>">
            <button class="btn btn-primary" name="new-staff">Submit</button>
        </form>
    </div>
</div>



        <?php 
        include('layout/footer.php');
        ?>
       
      
  
</body><!--end::Body-->

</html>