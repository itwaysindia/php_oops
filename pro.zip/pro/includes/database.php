<?php 
class db{

    protected $mysqli;

    public function __construct(){
        $this->mysqli = new mysqli(HOST, USERNAME, PASSWORD, DATABASE);
        if($this->mysqli->connect_error){
            die('Connection Error ('. $this->mysqli->connect_errno. ')' . $this->mysqli->connect_error);
        }
    }

    public function __destruct(){
        $this->mysqli->close();
    }

}

?>