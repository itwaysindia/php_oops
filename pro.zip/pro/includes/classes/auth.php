<?php
class auth extends db{

    public function getConnection(){
        return $this->mysqli;
    }


    function login(){
        echo "Login Method";
    }

    function register(){
        echo "Register Method";
       
       
        // $query->autoinsert('users');
    }

}


if(isset($_POST['login'])){
    $obj = new auth();
    $obj->login();
}
if(isset($_POST['signup'])){
    $obj = new auth();
    $obj->register();
}