<?php 

define('HOST', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASE', 'pro');

define('BASEURL', 'http://localhost/pro/');
// echo $_SERVER['REQUEST_URI'];
// echo "<br />". $folder = str_replace('/', '', $_SERVER['REQUEST_URI']);
// define('DIR', $folder);

define('CURRENCY', '&#8377');


define('DOCROOT', dirname(__FILE__));

/* load all classes here */
require_once('database.php');
require_once('classes/auth.php');
/* load all classes here */

spl_autoload_register(function($class){
    $filename = DOCROOT . "/classes/" . strtolower($class) . ".php";
    if(file_exists($filename)){
        include_once $filename;
    }
});







?>